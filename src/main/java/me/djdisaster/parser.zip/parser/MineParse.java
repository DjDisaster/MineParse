package me.djdisaster.parser;

import me.djdisaster.parser.parsing.Parser;
import me.djdisaster.parser.parsing.compiling.Compiler;
import me.djdisaster.parser.parsing.syntax.FunctionSyntax;
import me.djdisaster.parser.parsing.syntax.SimpleExpression;
import me.djdisaster.parser.parsing.syntax.SimpleSyntax;
import me.djdisaster.parser.parsing.syntax.Syntax;
import me.djdisaster.parser.parsing.tokens.Number;
import org.bukkit.plugin.java.JavaPlugin;

public final class MineParse extends JavaPlugin {

    @Override
    public void onEnable() {
        // Plugin startup logic

        Syntax.getSyntaxes().add(
                new SimpleSyntax("print %string%", "System.out.println(%expr-1%);")
        );
        Syntax.getSyntaxes().add(
                new SimpleSyntax("print %number%", "System.out.println(%expr-1%);")
        );
        Syntax.getSyntaxes().add(
                new FunctionSyntax("handled in the class.")
        );

        Syntax.getExpressions().add(
                new SimpleExpression(Number.class, "%number%+%number%", "%expr-1%+%expr-2%")
        );
        Compiler compiler = new Compiler();

        long parseStart = System.currentTimeMillis();
        Parser.parseLine(compiler, "function test(test: string, test2: number) :: number:");
        Parser.parseLine(compiler, "\tprint \"hello\"");
        Parser.parseLine(compiler, "function test2(test: string, test2: number) :: number:");
        Parser.parseLine(compiler, "\tprint 1+1");
        long parseEnd = System.currentTimeMillis();
        long compileStart = System.currentTimeMillis();
        compiler.getCompiled();
        long compileEnd = System.currentTimeMillis();
        System.out.println("Parsing took " + (parseEnd - parseStart) + " ms");
        System.out.println("Compiling took " + (compileEnd - compileStart) + " ms");


    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }


}
