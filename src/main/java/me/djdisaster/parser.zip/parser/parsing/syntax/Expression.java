package me.djdisaster.parser.parsing.syntax;

public class Expression {
}
